package br.com.unicuritiba.arenaplanetaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArenaPlanetariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
