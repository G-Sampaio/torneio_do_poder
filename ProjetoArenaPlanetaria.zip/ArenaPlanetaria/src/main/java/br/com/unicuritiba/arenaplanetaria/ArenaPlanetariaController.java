package br.com.unicuritiba.arenaplanetaria;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import br.com.unicuritiba.arenaplanetaria.models.Planetas;


import br.com.unicuritiba.arenaplanetaria.repositories.PlanetasRepository;
import ch.qos.logback.core.model.Model;

@Controller
public class ArenaPlanetariaController {
	
	@Autowired
	private PlanetasRepository repositorio;
	
	@GetMapping("/")
	public ModelAndView home() {
		
		List<Planetas> planetas = repositorio.findAll();
		
		ModelAndView view = new ModelAndView("index");
		view.addObject("planetas", planetas);
		
		return view;
		
	}
	
	@GetMapping("/cadastro")
	public ModelAndView create() {
		
		ModelAndView view = new ModelAndView("create");
		view.addObject("planetas", new Planetas());
		
		return view; 
		}
	
	@PostMapping("/cadastro")
	public String createPlanet(
			Planetas planetas, 
			Model model, 
			BindingResult result) {
		repositorio.save(planetas);
		return "redirect:/";
	}

}